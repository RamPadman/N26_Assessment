({
	close: function(component, event, helper) {
        component.set('v.showModal', false);
    },
    cancel: function(component, event, helper) {
        var ondecline = component.get('v.cancel');
        if (!$A.util.isUndefinedOrNull(ondecline)) {
            $A.enqueueAction(ondecline);
        }
        $A.enqueueAction(component.get('c.close'));
    },
    save: function(component, event, helper) {
        var action = component.get('v.save');
            $A.enqueueAction(action);
        $A.enqueueAction(component.get('c.close'));
    },
    show: function(component, event, helper) {
        component.set('v.showModal', true);
    }
})